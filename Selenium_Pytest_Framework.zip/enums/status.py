from enum import Enum


class Status(Enum):
    CONFIRM = "confirm"
    CANCEL = "cancel"
