import json
import os


class JSONUtility:
    @staticmethod
    def client_read_json(client_name, file_name):
        with open(os.path.dirname(os.getcwd()) + '/data/' + client_name + '/' + file_name + '.json') as config_file:
            data = json.load(config_file)
            return data
