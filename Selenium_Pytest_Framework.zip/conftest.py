import json
import os
import shutil
import subprocess
import time
from datetime import datetime

import allure
import pytest
from allure_commons.types import AttachmentType
from selenium import webdriver

from utils.driver_factory import DriverFactory

SUPPORTED_BROWSERS = ["chrome", "firefox", "edge"]


@pytest.fixture()
def config():
    with open(os.path.dirname(os.getcwd()) + '/config.json') as config_file:
        data = json.load(config_file)
    return data


@pytest.fixture()
def clients(config):
    result = {}
    for client in config["clients"]:
        for key, value in client.items():
            result[key] = value
    return result


@pytest.fixture()
def browser_setup(config):
    if "browser" not in config:
        raise Exception('The config file does not contain "browser"')
    elif config["browser"] not in SUPPORTED_BROWSERS:
        raise Exception(f'"{config["browser"]}" is not a supported browser')
    return config["browser"]


# @pytest.fixture(scope="session")
# def driver():
#     options = webdriver.ChromeOptions()
#     # options.add_argument('--headless')
#     driver = webdriver.Chrome(options=options)
#     yield driver
#     driver.quit()

# @pytest.fixture(scope="session")
# def driver(config):
#     browser_name = config['browser']
#     if browser_name == 'chrome':
#         driver = webdriver.Chrome()
#     elif browser_name == 'firefox':
#         driver = webdriver.Firefox()
#     else:
#         raise ValueError(f"Browser '{browser_name}' is not supported.")
#     yield driver
#     if request.node.rep_call.failed:
#         try:
#             # Make screenshot for Allure report
#             allure.attach(driver.get_screenshot_as_png(), name=request.function.__name__,
#                           attachment_type=allure.attachment_type.PNG)
#         except Exception as e:
#             print(f"Failed to take screenshot: {e}")
#     driver.quit()

@pytest.fixture()
def setup(request, config):
    driver = DriverFactory.get_driver(config)
    driver.implicitly_wait(config["timeout"])
    request.cls.driver = driver
    driver.maximize_window()
    yield driver
    if request.node.rep_call.failed:
        allure.attach(driver.get_screenshot_as_png(),
                      name="Test failed on step: " + request.function.__name__, attachment_type=AttachmentType.PNG)
        # allure.attach(driver.get_screenshot_as_png(), name=request.function.__name__,
        #               attachment_type=allure.attachment_type.PNG)
    driver.quit()


@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()
    setattr(item, "rep_" + rep.when, rep)


@pytest.fixture(scope="function", autouse=True)
def test_failed_check(request):
    yield
    # request.node is an "item" because we use the default
    # "function" scope
    if request.node.rep_setup.failed:
        print("setting up a test failed!", request.node.nodeid)
    elif request.node.rep_setup.passed:
        if request.node.rep_call.failed:
            # driver = request.node.funcargs['driver']
            # take_screenshot(driver, request.node.nodeid, request)
            print("executing test failed", request.node.nodeid)


def take_screenshot(driver, nodeid, request):
    time.sleep(1)
    file_name = f'{nodeid}_{datetime.today().strftime("%Y-%m-%d_%H:%M")}.png'.replace("/", "_").replace("::", "__")
    # driver.save_screenshot(file_name)
    allure.attach(driver.get_screenshot_as_png(), name="Title Verified",
                  attachment_type=allure.attachment_type.PNG)
    allure.attach(driver.get_screenshot_as_png(), name=request.function.__name__,
                  attachment_type=allure.attachment_type.PNG)

@pytest.hookimpl(tryfirst=True)
def pytest_sessionfinish(session, exitstatus):
    """Cleanup a testing directory once we are finished."""
    subprocess.run(['cd', 'tests'], check=True, shell=True)
    result = subprocess.Popen("allure generate --clean --output reports", shell=True)
    # print(result.stdout)
