
from selenium.webdriver.common.by import By

from locators.locators import LogInLocators
from .base_page import BasePage
from selenium.webdriver.support import expected_conditions as EC
import allure


class HomePage(BasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.search_box = (By.NAME, "q")
        self.url = "http://www.google.com"
        self.driver = driver

    @allure.step("Enter search query")
    def enter_search_term(self, term):
        self.driver.get(self.url)
        allure.attach(self.driver.get_screenshot_as_png(), name="Title Verified", attachment_type=allure.attachment_type.PNG)
        search_box = self.wait.until(EC.presence_of_element_located(self.search_box))
        search_box = self.wait_for_element(self.search_box)
        # search_box = self.wait_for_element(*LogInLocators.email_input)
        search_box.click()
        search_box.send_keys(term)

