import pytest

from pages.home_page import HomePage
import allure

from tests.base_test import BaseTest

users = [("nirt236@gmail.com", "123456"), ("elias@gmail.com", "12345Tr")]


@allure.severity(allure.severity_level.BLOCKER)
@allure.epic("Security")
@allure.feature("Login")
class TestExample(BaseTest):
    @allure.feature('Home Page')
    @allure.story('Search Functionality')
    @allure.description("invalid login")
    @allure.title("Login with invalid credentials test")
    @allure.tag("Tagged test")
    @pytest.mark.parametrize("email, password", users)
    @pytest.mark.run(order=3)
    @pytest.mark.flaky(reruns=1)
    def test_search(self, driver):
        home_page = HomePage(driver)
        with allure.step("Open Home Page"):
            home_page.enter_search_term("Selenium")

        with allure.step("Verify Title"):
            allure.attach(driver.get_screenshot_as_png(), name="Title Verified",
                          attachment_type=allure.attachment_type.PNG)
            assert "Selenium" in driver.title
