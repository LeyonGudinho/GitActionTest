import pytest

from pages.home_page import HomePage
import allure

from tests.base_test import BaseTest
from locators.locators import LogInLocators
from utils.json_reader import JSONUtility


# users = [("nirt236@gmail.com", "123456"), ("elias@gmail.com", "12345Tr")]

@pytest.mark.usefixtures("setup")     #Before Test setup
@allure.severity(allure.severity_level.BLOCKER)
@allure.epic("Security")
@allure.feature("Login")
class TestExample:
    @allure.feature('Home Page')
    @allure.story('Search Functionality')
    @allure.description("invalid login")
    @allure.title("Login with invalid credentials test")
    @allure.tag("Tagged test")
    # @pytest.mark.parametrize("email, password", users)
    @pytest.mark.parametrize("client_name", BaseTest.get_client_list())   #Dataprovider
    @pytest.mark.run(order=3)
    @pytest.mark.flaky(reruns=1)
    def test_search(self, client_name, config, clients):
        home_page = HomePage(self.driver)
        with allure.step("Open Home Page"):
            home_page.enter_search_term(client_name)
            self.driver.find_element(*LogInLocators.email_input).click()
            data = JSONUtility.client_read_json(client_name, "test")  # Get client folder data based on current client iteration
            print(allure.step(data["test"]))                                   # Get client folder data based on current client iteration
            print(allure.stepconfig["clients"][0][client_name]["default_market"])         # We can use config fixture and the traverse to client based on index
                                                                                          # but not suitable since we need incremental index which is not possible with parameterizing
            print(clients[client_name]["default_market"])                      # Better way is to clients fixture which directly filters the client by client_name
            print(allure.step(config["base_url"]))                             # Use config fixture only for config level fields and clients fixture for client level fields

        with allure.step("Verify Title"):
            # allure.attach(driver.get_screenshot_as_png(), name="Title Verified",
            #               attachment_type=allure.attachment_type.PNG)
            assert "Selenium" in self.driver.title

    @pytest.mark.parametrize("client_name", BaseTest.get_client_list())
    def test_search_2(self, client_name, config):
        home_page = HomePage(self.driver)
        with allure.step("Open Home Page"):
            home_page.enter_search_term(client_name)
            self.driver.find_element(*LogInLocators.email_input).click()
            data = JSONUtility.client_read_json(client_name, "test")
        print(allure.step(data["test"]))
        with allure.step("Verify Title"):
            # allure.attach(driver.get_screenshot_as_png(), name="Title Verified",
            #               attachment_type=allure.attachment_type.PNG)
            assert "Google" in self.driver.title

#
