import json
import os

from selenium.webdriver.support.wait import WebDriverWait

from pages.base_page import BasePage


class BaseTest:

    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 5)


    @staticmethod
    def get_config():
        with open(os.path.dirname(os.getcwd()) + '/config.json') as config_file:
            data = json.load(config_file)
        return data

    @staticmethod
    def get_client_list():
        with open(os.path.dirname(os.getcwd()) + '/config.json') as config_file:
            data = json.load(config_file)

        client_names = []
        for client_group in data['clients']:
            for client_key, client_info in client_group.items():
                client_names.append(client_key)
        return client_names

    # @staticmethod
    # def get_client_list_info():
    #     with open(os.path.dirname(os.getcwd()) + '/config.json') as config_file:
    #         data = json.load(config_file)
    #
    #     client_names = []
    #     for client_group in data['clients']:
    #         for client_key, client_info in client_group.items():
    #             client_names.append(client_info['name'])
    #     return client_names
