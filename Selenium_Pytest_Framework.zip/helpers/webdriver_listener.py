import logging
import datetime
from selenium.webdriver.support.events import AbstractEventListener


class WebDriverListener(AbstractEventListener):
    log_filename = datetime.datetime.now().strftime("%Y%m%d")
    logging.basicConfig(
        # log file will be created in "tests" directory. Feel free to change the path or filename
        filename=f"{log_filename}.log",
        format="%(asctime)s: %(levelname)s: %(message)s",
        level=logging.INFO
    )

    def __init__(self, config):
        self.logger = logging.getLogger("selenium")
        self.config = config

    def before_navigate_to(self, url, driver):
        self.logger.info(f"Navigating to {url}")

    def after_navigate_to(self, url, driver):
        self.logger.info(f"{url} opened")

    def before_find(self, by, value, driver):
        self.logger.info(f"Searching for element by {by} {value}")

    def after_find(self, by, value, driver):
        if self.config.get('highlight_elements') is True:
            element = driver.find_element(by, value)
            driver.execute_script("arguments[0].style.border='2px dashed red';", element)
            # driver.execute_script("arguments[0].style.border='6px solid blue'; arguments[0].style.border='3px solid'; arguments[0].style.borderTopColor='red'; arguments[0].style.borderRightColor='bisque', arguments[0].style.borderBottomColor='orange', arguments[0].style.borderLeftColor='yellow'", element)
        self.logger.info(f"Element by {by} {value} found")

    def before_click(self, element, driver):
        if element.get_attribute("text") is None:
            self.logger.info(f"Clicking on {element.get_attribute('class')}")
        else:
            self.logger.info(f"Clicking on {element.get_attribute('text')}")
        if self.config.get('highlight_elements') is True:
            driver.execute_script("arguments[0].style.border='2px solid blue';", element)

    def after_click(self, element, driver):
        if element.get_attribute("text") is None:
            self.logger.info(f"{element.get_attribute('class')} clicked")
        else:
            self.logger.info(f"{element.get_attribute('text')} clicked")
        if self.config.get('highlight_elements') is True:
            driver.execute_script("arguments[0].style.border='2px dashed red';", element)

    def before_change_value_of(self, element, driver):
        self.logger.info(f"{element.get_attribute('text')} value changed")

    def before_quit(self, driver):
        self.logger.info("Driver quitting")

    def after_quit(self, driver):
        self.logger.info("Driver quitted")

    def on_exception(self, exception, driver):
        self.logger.info(exception)
